"""
Option A — Fast Hackathon Model
Transfer learning with EfficientNet-B0 / ResNet-50 for binary classification
(damaged vs. not-damaged).
"""
import torch
import torch.nn as nn
import timm


class DamageClassifier(nn.Module):
    """
    Binary classifier: Damaged / Not-Damaged.
    Uses a pretrained backbone from `timm` for fast convergence.
    """

    def __init__(self, backbone: str = "efficientnet_b0", num_classes: int = 2, pretrained: bool = True):
        super().__init__()
        self.backbone_name = backbone
        self.model = timm.create_model(backbone, pretrained=pretrained, num_classes=num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.model(x)

    def freeze_backbone(self):
        """Freeze all layers except the classifier head — great for few-shot learning."""
        for name, param in self.model.named_parameters():
            if "classifier" not in name and "fc" not in name and "head" not in name:
                param.requires_grad = False

    def unfreeze_all(self):
        """Unfreeze everything for fine-tuning."""
        for param in self.model.parameters():
            param.requires_grad = True

    @staticmethod
    def available_backbones() -> list:
        """Return a curated list of fast-to-train backbones."""
        return [
            "efficientnet_b0",
            "efficientnet_b2",
            "resnet50",
            "resnet34",
            "mobilenetv3_large_100",
            "convnext_tiny",
        ]


def build_classifier(backbone: str = "efficientnet_b0", num_classes: int = 2, freeze: bool = True) -> DamageClassifier:
    """
    Factory function — builds and optionally freezes a classifier.

    Args:
        backbone:    timm model name
        num_classes: number of output classes
        freeze:      whether to freeze backbone weights

    Returns:
        DamageClassifier ready for training
    """
    model = DamageClassifier(backbone=backbone, num_classes=num_classes, pretrained=True)
    if freeze:
        model.freeze_backbone()
    return model


# ──────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    model = build_classifier("efficientnet_b0", num_classes=2, freeze=True)
    dummy = torch.randn(1, 3, 224, 224)
    out = model(dummy)
    print(f"Output shape: {out.shape}")          # → [1, 2]
    print(f"Trainable params: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")
