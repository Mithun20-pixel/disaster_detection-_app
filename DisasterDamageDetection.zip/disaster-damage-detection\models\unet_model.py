"""
Option B — Advanced Segmentation Model
U-Net architecture for pixel-level damage segmentation.
"""
import torch
import torch.nn as nn
import torchvision.models as models


class ConvBlock(nn.Module):
    """Double convolution block used in U-Net."""

    def __init__(self, in_ch: int, out_ch: int):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class UNetSegmentation(nn.Module):
    """
    U-Net with a pretrained ResNet-34 encoder for damage segmentation.
    Produces a pixel-level mask:  0 = no damage,  1 = damaged.
    """

    def __init__(self, num_classes: int = 1, pretrained_encoder: bool = True):
        super().__init__()

        # ── Encoder (ResNet-34 backbone) ─────────────────────────────────────
        encoder = models.resnet34(
            weights=models.ResNet34_Weights.DEFAULT if pretrained_encoder else None
        )
        self.enc1 = nn.Sequential(encoder.conv1, encoder.bn1, encoder.relu)   # 64
        self.pool1 = encoder.maxpool
        self.enc2 = encoder.layer1   # 64
        self.enc3 = encoder.layer2   # 128
        self.enc4 = encoder.layer3   # 256
        self.enc5 = encoder.layer4   # 512

        # ── Decoder ──────────────────────────────────────────────────────────
        self.up5 = nn.ConvTranspose2d(512, 256, 2, stride=2)
        self.dec5 = ConvBlock(512, 256)

        self.up4 = nn.ConvTranspose2d(256, 128, 2, stride=2)
        self.dec4 = ConvBlock(256, 128)

        self.up3 = nn.ConvTranspose2d(128, 64, 2, stride=2)
        self.dec3 = ConvBlock(128, 64)

        self.up2 = nn.ConvTranspose2d(64, 64, 2, stride=2)
        self.dec2 = ConvBlock(128, 64)

        self.up1 = nn.ConvTranspose2d(64, 32, 2, stride=2)
        self.dec1 = ConvBlock(32, 32)

        self.final = nn.Conv2d(32, num_classes, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Encoder
        e1 = self.enc1(x)                       # /2
        e2 = self.enc2(self.pool1(e1))           # /4
        e3 = self.enc3(e2)                       # /8
        e4 = self.enc4(e3)                       # /16
        e5 = self.enc5(e4)                       # /32

        # Decoder with skip connections
        d5 = self.up5(e5)
        d5 = self._pad_and_cat(d5, e4)
        d5 = self.dec5(d5)

        d4 = self.up4(d5)
        d4 = self._pad_and_cat(d4, e3)
        d4 = self.dec4(d4)

        d3 = self.up3(d4)
        d3 = self._pad_and_cat(d3, e2)
        d3 = self.dec3(d3)

        d2 = self.up2(d3)
        d2 = self._pad_and_cat(d2, e1)
        d2 = self.dec2(d2)

        d1 = self.up1(d2)
        d1 = self.dec1(d1)

        return self.final(d1)

    @staticmethod
    def _pad_and_cat(x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        """Handle size mismatches between upsampled and skip connection tensors."""
        diff_h = skip.size(2) - x.size(2)
        diff_w = skip.size(3) - x.size(3)
        x = nn.functional.pad(x, [diff_w // 2, diff_w - diff_w // 2,
                                   diff_h // 2, diff_h - diff_h // 2])
        return torch.cat([x, skip], dim=1)


def build_unet(num_classes: int = 1, pretrained: bool = True) -> UNetSegmentation:
    """Factory function — builds a pretrained U-Net segmentation model."""
    return UNetSegmentation(num_classes=num_classes, pretrained_encoder=pretrained)


# ──────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    model = build_unet(num_classes=1)
    dummy = torch.randn(1, 3, 256, 256)
    out = model(dummy)
    print(f"Output shape: {out.shape}")    # → [1, 1, 256, 256]
    print(f"Total params: {sum(p.numel() for p in model.parameters()):,}")
