import cv2
import numpy as np

def calculate_ssim(img1, img2):
    """
    Calculate Structural Similarity Index (SSIM) between two images.
    Returns: SSIM score (-1 to 1) and SSIM difference image.
    """
    # Convert to grayscale
    gray1 = cv2.cvtColor(img1, cv2.COLOR_RGB2GRAY)
    gray2 = cv2.cvtColor(img2, cv2.COLOR_RGB2GRAY)
    
    # Calculate SSIM using OpenCV
    ssim_score, diff = cv2.metrics.structuralSimilarity(gray1, gray2, full=True)
    # Since OpenCV may not have it strictly in older versions, here's manual SSIM or using skimage:
    # We will use scikit-image's structural_similarity in an actual project,
    # but to avoid adding a dependency just for this, we can approximate structural difference.
    
    return ssim_score, diff

def structural_difference(img1, img2):
    """
    Calculate structural change between Before and After images.
    Returns: change score (%), diff map.
    """
    gray1 = cv2.cvtColor(img1, cv2.COLOR_RGB2GRAY)
    gray2 = cv2.cvtColor(img2, cv2.COLOR_RGB2GRAY)
    
    # Absolute difference
    diff = cv2.absdiff(gray1, gray2)
    
    # Thresholding to find significant changes
    _, thresh = cv2.threshold(diff, 30, 255, cv2.THRESH_BINARY)
    
    # Morphology to remove noise
    kernel = np.ones((5,5), np.uint8)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    
    change_ratio = np.sum(thresh == 255) / thresh.size
    
    return change_ratio, thresh

def detect_water(image):
    """
    Detect water regions using HSV thresholding.
    Optimized for flood detection in satellite imagery.
    Returns: binary mask and water percentage.
    """
    hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
    
    # Define range for muddy/brown flood water and clear water
    # Muddy water
    lower_mud = np.array([10, 50, 50])
    upper_mud = np.array([30, 255, 255])
    
    # Blue water
    lower_blue = np.array([100, 50, 50])
    upper_blue = np.array([130, 255, 255])
    
    mask_mud = cv2.inRange(hsv, lower_mud, upper_mud)
    mask_blue = cv2.inRange(hsv, lower_blue, upper_blue)
    
    mask = cv2.bitwise_or(mask_mud, mask_blue)
    
    # Cleanup mask
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    
    water_ratio = np.sum(mask == 255) / mask.size
    
    return mask, water_ratio

def vegetation_loss(before_img, after_img):
    """
    Estimate vegetation loss using pseudo-NDVI since we don't have true NIR bands
    in standard RGB images. (Using Excess Green Index - ExG).
    Returns: loss mask and lost percentage.
    """
    def exg(img):
        b, g, r = cv2.split(img.astype(float))
        # ExG = 2G - R - B
        index = 2 * g - r - b
        return index

    exg_before = exg(before_img)
    exg_after = exg(after_img)
    
    # Loss is where before had vegetation but after doesn't
    # Threshold for considering it vegetation (ExG > 20)
    veg_before = exg_before > 20
    veg_after = exg_after > 20
    
    loss_mask = np.logical_and(veg_before, np.logical_not(veg_after))
    
    loss_ratio = np.sum(loss_mask) / (np.sum(veg_before) + 1e-6)
    
    return loss_mask.astype(np.uint8) * 255, loss_ratio

def edge_comparison(before_img, after_img):
    """
    Compare Canny edges from before and after images to detect structural changes (collapsed buildings/roads).
    """
    b_gray = cv2.cvtColor(before_img, cv2.COLOR_RGB2GRAY)
    a_gray = cv2.cvtColor(after_img, cv2.COLOR_RGB2GRAY)
    
    b_edges = cv2.Canny(b_gray, 100, 200)
    a_edges = cv2.Canny(a_gray, 100, 200)
    
    # Edges present before but not after (structural loss)
    struct_loss = cv2.subtract(b_edges, a_edges)
    
    # Normalize
    loss_ratio = np.sum(struct_loss == 255) / (np.sum(b_edges == 255) + 1e-6)
    
    return struct_loss, loss_ratio
