"""
Prediction utilities — run inference with either the CNN classifier
or the U-Net segmentation model.
"""
import os
import torch
import torch.nn.functional as F
import numpy as np
from typing import Tuple, Dict, Optional

from config import IMAGE_SIZE, SEGMENTATION_SIZE, CLASS_NAMES, DEVICE, MODEL_DIR
from models.cnn_model import build_classifier
from models.unet_model import build_unet
from utils.preprocessing import preprocess_for_model


def get_device() -> torch.device:
    """Auto-detect best available device."""
    if DEVICE == "cuda" and torch.cuda.is_available():
        return torch.device("cuda")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


import cv2

# ═══════════════════════════════════════════════════════════════════════════════
# Smart Demo Heuristics (Fallback for Untrained Models)
# ═══════════════════════════════════════════════════════════════════════════════

def heuristic_damage_score(image: np.ndarray) -> float:
    """Uses OpenCV to estimate damage probability if the ML model is untrained."""
    # 1. Edge density (Rubble/debris creates high-frequency edges)
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 100, 200)
    edge_score = np.clip((np.sum(edges > 0) / edges.size) * 3.0, 0, 1)

    # 2. Color anomaly (Muddy flood waters = brown/gray hues)
    hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
    lower_brown = np.array([10, 40, 40])
    upper_brown = np.array([30, 255, 200])
    brown_mask = cv2.inRange(hsv, lower_brown, upper_brown)
    brown_score = np.clip((np.sum(brown_mask > 0) / brown_mask.size) * 5.0, 0, 1)

    # 3. Missing vegetation (Healthy vegetation = low damage)
    r, g, b = cv2.split(image.astype(np.float32))
    exg = 2 * g - r - b
    veg_mask = exg > 30
    veg_score = 1.0 - np.clip((np.sum(veg_mask) / max(veg_mask.size, 1)) * 2.0, 0, 1)

    # Combined weighted score
    score = (edge_score * 0.5) + (brown_score * 0.4) + (veg_score * 0.1)
    return float(np.clip(score * 1.5, 0.1, 0.95))


def heuristic_segmentation_mask(image: np.ndarray, threshold: float) -> Tuple[np.ndarray, float]:
    """Generates a demo segmentation mask using edge and color detection."""
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 100, 200)
    
    # Dilate edges to create region blocks
    kernel = np.ones((5, 5), np.uint8)
    dilated_edges = cv2.dilate(edges, kernel, iterations=3)
    
    # Flood waters
    hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
    lower_brown = np.array([10, 40, 40])
    upper_brown = np.array([30, 255, 200])
    brown_mask = cv2.inRange(hsv, lower_brown, upper_brown)
    
    # Combine
    mask = cv2.bitwise_or(dilated_edges, brown_mask)
    
    # Smooth mask
    mask = cv2.GaussianBlur(mask, (21, 21), 0)
    binary_mask = (mask > (threshold * 255)).astype(np.uint8)
    
    damage_ratio = float(binary_mask.sum()) / binary_mask.size
    return binary_mask, damage_ratio

# ═══════════════════════════════════════════════════════════════════════════════
# Classification Prediction
# ═══════════════════════════════════════════════════════════════════════════════

def predict_damage_classification(
    image: np.ndarray,
    model: Optional[torch.nn.Module] = None,
    model_path: Optional[str] = None,
    backbone: str = "efficientnet_b0",
    is_trained: bool = True,
) -> Dict:
    """
    Predict damage from a satellite image using the CNN classifier.

    Args:
        image:      RGB numpy array (H, W, 3)
        model:      Optional pre-loaded model
        model_path: Optional path to saved checkpoint
        backbone:   timm backbone name (if loading fresh)
        is_trained: If False, falls back to OpenCV heuristics for demo purposes.

    Returns:
        dict with keys: label, confidence, probabilities, class_index
    """
    if not is_trained:
        prob_damaged = heuristic_damage_score(image)
        prob_safe = 1.0 - prob_damaged
        probs = np.array([prob_safe, prob_damaged])
        class_idx = 1 if prob_damaged > 0.5 else 0
        return {
            "label": CLASS_NAMES[class_idx],
            "confidence": float(probs[class_idx]),
            "probabilities": {"No Damage": float(prob_safe), "Damaged": float(prob_damaged)},
            "class_index": class_idx,
        }

    device = get_device()

    # Load or build model
    if model is None:
        model = build_classifier(backbone=backbone, num_classes=len(CLASS_NAMES), freeze=False)
        if model_path and os.path.exists(model_path):
            state = torch.load(model_path, map_location=device, weights_only=True)
            model.load_state_dict(state)
    model = model.to(device).eval()

    # Preprocess
    tensor = preprocess_for_model(image, img_size=IMAGE_SIZE).to(device)

    # Inference
    with torch.no_grad():
        logits = model(tensor)
        probs = F.softmax(logits, dim=1).cpu().numpy()[0]

    class_idx = int(np.argmax(probs))
    return {
        "label": CLASS_NAMES[class_idx],
        "confidence": float(probs[class_idx]),
        "probabilities": {name: float(p) for name, p in zip(CLASS_NAMES, probs)},
        "class_index": class_idx,
    }


def predict_damage_classification_demo(image: np.ndarray) -> Dict:
    """
    Demo prediction using the pretrained model weights directly.
    Uses the model's raw (untrained) output — useful for demonstrating
    the pipeline before training on actual data.
    """
    return predict_damage_classification(image, model_path=None)


# ═══════════════════════════════════════════════════════════════════════════════
# Segmentation Prediction
# ═══════════════════════════════════════════════════════════════════════════════

def predict_damage_segmentation(
    image: np.ndarray,
    model: Optional[torch.nn.Module] = None,
    model_path: Optional[str] = None,
    threshold: float = 0.5,
    is_trained: bool = True,
) -> Tuple[np.ndarray, float]:
    """
    Predict damage segmentation mask using U-Net.

    Args:
        image:      RGB numpy array (H, W, 3)
        model:      Optional pre-loaded model
        model_path: Optional path to saved checkpoint
        threshold:  Binary threshold for the mask
        is_trained: If False, falls back to OpenCV heuristics

    Returns:
        mask:         Binary mask (H, W) of damaged areas
        damage_ratio: Fraction of pixels classified as damaged
    """
    if not is_trained:
        return heuristic_segmentation_mask(image, threshold)

    device = get_device()

    # Load model
    if model is None:
        model = build_unet(num_classes=1, pretrained=True)
        if model_path and os.path.exists(model_path):
            state = torch.load(model_path, map_location=device, weights_only=True)
            model.load_state_dict(state)
    model = model.to(device).eval()

    # Preprocess
    tensor = preprocess_for_model(image, img_size=SEGMENTATION_SIZE).to(device)

    # Inference
    with torch.no_grad():
        logits = model(tensor)
        probs = torch.sigmoid(logits).cpu().numpy()[0, 0]   # [256, 256]

    # Resize probabilities back to the original input image dimensions
    probs = cv2.resize(probs, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_LINEAR)

    mask = (probs > threshold).astype(np.uint8)
    damage_ratio = float(mask.sum()) / mask.size

    return mask, damage_ratio


# ═══════════════════════════════════════════════════════════════════════════════
# Combined Prediction
# ═══════════════════════════════════════════════════════════════════════════════

def full_analysis(
    image: np.ndarray,
    classification_model=None,
    segmentation_model=None,
) -> Dict:
    """Run both classification + segmentation and return a merged result."""
    cls_result = predict_damage_classification(image, model=classification_model)
    mask, damage_ratio = predict_damage_segmentation(image, model=segmentation_model)

    return {
        **cls_result,
        "mask": mask,
        "damage_ratio": damage_ratio,
        "damage_percentage": f"{damage_ratio * 100:.1f}%",
    }
