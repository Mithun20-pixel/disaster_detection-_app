"""
Image preprocessing utilities for satellite imagery.
"""
import cv2
import numpy as np
import torch
from torchvision import transforms
from PIL import Image
from typing import Tuple, Optional
import albumentations as A
from albumentations.pytorch import ToTensorV2

from config import IMAGE_SIZE, SEGMENTATION_SIZE


# ─── Standard Transforms ────────────────────────────────────────────────────

def get_classification_transforms(train: bool = True, img_size: int = IMAGE_SIZE) -> transforms.Compose:
    """
    Returns torchvision transforms for the CNN classifier.
    Uses augmentation during training for better generalization.
    """
    if train:
        return transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomVerticalFlip(p=0.3),
            transforms.RandomRotation(15),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.1),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225]),
        ])
    else:
        return transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225]),
        ])


def get_segmentation_transforms(train: bool = True, img_size: int = SEGMENTATION_SIZE) -> A.Compose:
    """
    Returns albumentations transforms for U-Net segmentation.
    Paired image-mask augmentations.
    """
    if train:
        return A.Compose([
            A.Resize(img_size, img_size),
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.3),
            A.RandomRotate90(p=0.5),
            A.RandomBrightnessContrast(brightness_limit=0.2, contrast_limit=0.2, p=0.5),
            A.GaussNoise(p=0.2),
            A.Normalize(mean=[0.485, 0.456, 0.406],
                        std=[0.229, 0.224, 0.225]),
            ToTensorV2(),
        ])
    else:
        return A.Compose([
            A.Resize(img_size, img_size),
            A.Normalize(mean=[0.485, 0.456, 0.406],
                        std=[0.229, 0.224, 0.225]),
            ToTensorV2(),
        ])


# ─── Direct Image Processing ────────────────────────────────────────────────

def load_and_preprocess(image_path: str, target_size: Tuple[int, int] = (IMAGE_SIZE, IMAGE_SIZE)) -> np.ndarray:
    """Load an image via OpenCV and preprocess it."""
    img = cv2.imread(image_path)
    if img is None:
        raise FileNotFoundError(f"Cannot load image: {image_path}")
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, target_size, interpolation=cv2.INTER_AREA)
    return img


def preprocess_for_model(image: np.ndarray, img_size: int = IMAGE_SIZE) -> torch.Tensor:
    """Convert a numpy RGB image to a normalized tensor batch."""
    pil_img = Image.fromarray(image)
    transform = get_classification_transforms(train=False, img_size=img_size)
    tensor = transform(pil_img)      # [3, H, W]
    return tensor.unsqueeze(0)        # [1, 3, H, W]


def preprocess_uploaded_image(uploaded_file, img_size: int = IMAGE_SIZE) -> Tuple[np.ndarray, torch.Tensor]:
    """
    Process an uploaded file (Streamlit UploadedFile or file path) into
    both a displayable numpy array and a model-ready tensor.
    """
    if isinstance(uploaded_file, str):
        image = load_and_preprocess(uploaded_file, (img_size, img_size))
    else:
        file_bytes = np.frombuffer(uploaded_file.read(), dtype=np.uint8)
        image = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image = cv2.resize(image, (img_size, img_size))

    tensor = preprocess_for_model(image, img_size)
    return image, tensor


def enhance_satellite_image(image: np.ndarray) -> np.ndarray:
    """Enhance satellite image slightly to pop features without adding artifacts."""
    # 1. Very mild unsharp masking for clarity
    gaussian = cv2.GaussianBlur(image, (9, 9), 10.0)
    sharpened = cv2.addWeighted(image, 1.2, gaussian, -0.2, 0)
    
    # 2. Slight contrast adjustment (alpha) and brightness (beta)
    enhanced = cv2.convertScaleAbs(sharpened, alpha=1.05, beta=5)
    
    return enhanced
