"""
Visualization utilities — heatmaps, overlays, damage maps, and Grad-CAM.
"""
import cv2
import numpy as np
import torch
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from typing import Optional, Tuple


# ─── Custom Color Map ────────────────────────────────────────────────────────
DAMAGE_CMAP = LinearSegmentedColormap.from_list(
    "damage",
    [(0, "#2ecc71"), (0.5, "#f39c12"), (1.0, "#e74c3c")],  # green → orange → red
)


def create_damage_heatmap(
    image: np.ndarray,
    damage_score: float,
    title: str = "Damage Analysis",
) -> np.ndarray:
    """
    Create a heatmap overlay on the image simulating
    damage probability distribution.
    """
    h, w = image.shape[:2]

    # Simulate a spatial damage probability map using Gaussian blobs
    heatmap = np.zeros((h, w), dtype=np.float32)
    num_blobs = max(1, int(damage_score * 8))
    rng = np.random.default_rng(42)

    for _ in range(num_blobs):
        cx, cy = rng.integers(w // 4, 3 * w // 4), rng.integers(h // 4, 3 * h // 4)
        sigma = rng.integers(20, 60)
        Y, X = np.ogrid[:h, :w]
        blob = np.exp(-((X - cx) ** 2 + (Y - cy) ** 2) / (2 * sigma ** 2))
        heatmap += blob * damage_score

    heatmap = np.clip(heatmap, 0, 1)

    # Colorize and blend
    colored = (plt.cm.jet(heatmap)[:, :, :3] * 255).astype(np.uint8)
    blended = cv2.addWeighted(image, 0.6, colored, 0.4, 0)
    return blended


def create_segmentation_overlay(
    image: np.ndarray,
    mask: np.ndarray,
    alpha: float = 0.45,
    color: Tuple[int, int, int] = (231, 76, 60),
) -> np.ndarray:
    """
    Overlay a binary segmentation mask on the image.
    Damaged pixels are tinted with `color`.
    """
    overlay = image.copy()
    damage_mask = mask > 0.5

    overlay[damage_mask] = (
        np.array(overlay[damage_mask], dtype=np.float32) * (1 - alpha)
        + np.array(color, dtype=np.float32) * alpha
    ).astype(np.uint8)

    # Draw contours around damaged regions
    mask_uint8 = (damage_mask.astype(np.uint8) * 255)
    contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(overlay, contours, -1, color, 2)

    return overlay


def draw_damage_bboxes(
    image: np.ndarray,
    mask: np.ndarray,
    min_area: int = 200,
) -> np.ndarray:
    """Draw bounding boxes around detected damaged regions."""
    result = image.copy()
    mask_uint8 = ((mask > 0.5).astype(np.uint8) * 255)
    contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < min_area:
            continue
        x, y, w, h = cv2.boundingRect(cnt)
        cv2.rectangle(result, (x, y), (x + w, y + h), (231, 76, 60), 2)
        label = f"Damage: {area:.0f}px"
        cv2.putText(result, label, (x, y - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)

    return result


def create_severity_map(damage_score: float, size: Tuple[int, int] = (300, 300)) -> np.ndarray:
    """Create a circular severity gauge visualization."""
    fig, ax = plt.subplots(1, 1, figsize=(3, 3), dpi=100, facecolor="#0e1117")
    ax.set_facecolor("#0e1117")

    # Determine severity level
    if damage_score < 0.3:
        severity, color = "LOW", "#2ecc71"
    elif damage_score < 0.7:
        severity, color = "MODERATE", "#f39c12"
    else:
        severity, color = "SEVERE", "#e74c3c"

    # Draw gauge
    theta = np.linspace(0, 2 * np.pi * damage_score, 100)
    r = np.ones_like(theta)
    ax.fill_between(theta, 0.6, 1.0, alpha=0.8, color=color)
    theta_bg = np.linspace(2 * np.pi * damage_score, 2 * np.pi, 100)
    ax.fill_between(theta_bg, 0.6, 1.0, alpha=0.15, color="#ffffff")

    ax.set_ylim(0, 1.1)
    ax.set_xlim(-0.1, 2 * np.pi + 0.1)
    ax.axis("off")

    # Center text
    fig.text(0.5, 0.5, f"{damage_score:.0%}", ha="center", va="center",
             fontsize=22, fontweight="bold", color=color)
    fig.text(0.5, 0.35, severity, ha="center", va="center",
             fontsize=10, fontweight="bold", color=color)

    fig.tight_layout()
    fig.canvas.draw()
    data = np.frombuffer(fig.canvas.buffer_rgba(), dtype=np.uint8)
    w, h = fig.canvas.get_width_height()
    result = data.reshape(h, w, 4)[:, :, :3]
    plt.close(fig)
    return result


def create_before_after(before: np.ndarray, after: np.ndarray) -> np.ndarray:
    """Create a side-by-side before/after comparison image."""
    h = max(before.shape[0], after.shape[0])
    w = before.shape[1] + after.shape[1] + 20

    canvas = np.zeros((h, w, 3), dtype=np.uint8)
    canvas[:, :, :] = 30  # dark background

    # Place images
    canvas[:before.shape[0], :before.shape[1]] = before
    canvas[:after.shape[0], before.shape[1] + 20:] = after

    # Labels
    cv2.putText(canvas, "BEFORE", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (46, 204, 113), 2)
    cv2.putText(canvas, "AFTER", (before.shape[1] + 30, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (231, 76, 60), 2)

    return canvas


def plot_training_history(train_losses: list, val_losses: list, train_accs: list, val_accs: list) -> plt.Figure:
    """Plot training history curves."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4), facecolor="#0e1117")

    for ax in (ax1, ax2):
        ax.set_facecolor("#1a1f2e")
        ax.tick_params(colors="#aaa")
        ax.spines["bottom"].set_color("#333")
        ax.spines["left"].set_color("#333")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    epochs = range(1, len(train_losses) + 1)
    ax1.plot(epochs, train_losses, "#3498db", linewidth=2, label="Train Loss")
    ax1.plot(epochs, val_losses, "#e74c3c", linewidth=2, label="Val Loss")
    ax1.set_xlabel("Epoch", color="#aaa")
    ax1.set_ylabel("Loss", color="#aaa")
    ax1.legend(facecolor="#1a1f2e", edgecolor="#333", labelcolor="#ddd")
    ax1.set_title("Training & Validation Loss", color="#fafafa")

    ax2.plot(epochs, train_accs, "#2ecc71", linewidth=2, label="Train Acc")
    ax2.plot(epochs, val_accs, "#f39c12", linewidth=2, label="Val Acc")
    ax2.set_xlabel("Epoch", color="#aaa")
    ax2.set_ylabel("Accuracy", color="#aaa")
    ax2.legend(facecolor="#1a1f2e", edgecolor="#333", labelcolor="#ddd")
    ax2.set_title("Training & Validation Accuracy", color="#fafafa")

    fig.tight_layout()
    return fig
